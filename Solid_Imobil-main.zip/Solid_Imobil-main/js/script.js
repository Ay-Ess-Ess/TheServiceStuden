console.log('Hellow felass. )');
function scrollFunction() {
    const element = document.querySelector(".oferte");
    element.scrollIntoView({ behavior: 'smooth'});
}
