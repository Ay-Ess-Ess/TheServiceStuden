function goRight() {
    document.querySelector(".carosel").scrollLeft += 240;
}
function goLeft() {
    document.querySelector(".carosel").scrollLeft -= 240;
}
